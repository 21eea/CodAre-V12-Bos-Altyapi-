Bu Aştyapı eeaemrege#0001 tarafından CodAre için hazırlanmıştır 




NOT: discord.js yükleyerek altyapıyı kullanabilirsiniz