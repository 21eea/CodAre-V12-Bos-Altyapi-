const Discord = require('discord.js');
const ayarlar = require('../ayarlar.json');

var prefix = ayarlar.prefix;

module.exports = client => {
var oyun = [
    `CodAre V12 Boş Altyapı`
    ];

    setInterval(function() {

        var random = Math.floor(Math.random()*(oyun.length-0+1)+0);

        client.user.setActivity(oyun[random], "CodAre" );
        }, 2 * 2500);

  console.log(`${client.user.username} Aktif, Komutlar Yüklendi!`);
  client.user.setStatus("dnd");
  console.log(`Sunucu Sayısı => ${client.guilds.cache.size}`);
  console.log(`Kullanıcı Sayısı => ${client.guilds.cache.reduce((a, b) => a + b.memberCount, 0)}`)
};

const log = message => {
  console.log(`[${moment().format("YYYY-MM-DD HH:mm:ss")}] ${message}`);
};

